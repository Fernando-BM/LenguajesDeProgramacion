fac :: Integer->Integer
fac 0 = 1
fac n = n * fac (n-1)
 

